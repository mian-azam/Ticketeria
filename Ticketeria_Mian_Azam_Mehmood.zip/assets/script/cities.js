export default{  "cities": [
    {
      "name": "Alberta"
    },
    {
      "name": "Halifax"
    },
    {
      "name": "Ottawa"
    },
    {
      "name": "Quebec"
    },
    {
      "name": "Saskatchewan"
    },
    {
      "name": "Vancouver"
    },
    {
      "name": "Victoria"
    },
    {
      "name": "Winnipeg"
    }
  ]
}